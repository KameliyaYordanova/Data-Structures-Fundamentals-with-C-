﻿namespace Problem02.DoublyLinkedList
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class DoublyLinkedList<T> : IAbstractLinkedList<T>
    {
        private Node<T> head;
        private Node<T> tail;

        public DoublyLinkedList()
        {
            this.head = this.tail = null;
            this.Count = 0;
        }

        public int Count { get; private set; }

        public void AddFirst(T item)
        {
            Node<T> toInsert = new Node<T>
            {
                Item = item,
            };

            if (Count == 0)
            {
                head = tail = toInsert;
            }
            else
            {
                head.Previous = toInsert;
                toInsert.Next = head;
                head = toInsert;
            }

            Count++;
        }

        public void AddLast(T item)
        {
            Node<T> toInsert = new Node<T>
            {
                Item = item,
            };

            if (Count == 0)
            {
                head = tail = toInsert;
            }
            else
            {
                toInsert.Previous = tail;
                tail.Next = toInsert;
                tail = toInsert;
            }

            Count++;
        }

        public T GetFirst()
        {
            EnsureNotEmpty();
            return head.Item;
        }

        public T GetLast()
        {
            EnsureNotEmpty();

            return tail.Item;
        }

        public T RemoveFirst()
        {
            EnsureNotEmpty();
            Node<T> current = head;
            if (Count == 1)
            {
                head = tail = null;
            }
            else
            {
                Node<T> newHead = head.Next;
                newHead.Previous = null;
                head = newHead;
            }
            Count--;
            return current.Item;
        }

        public T RemoveLast()
        {
            EnsureNotEmpty();
            Node<T> current = tail;
            if (Count == 1)
            {
                head = tail = null;
            }
            else
            {
                Node<T> newTail = tail.Previous;
                newTail.Next = null;
                tail = newTail;
            }
            Count--;
            return current.Item;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> current = head;

            while (current != null)
            {
                yield return current.Item;
                current = current.Next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        private void EnsureNotEmpty()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException("Double linkedList is empty");
            }
        }
    }
}