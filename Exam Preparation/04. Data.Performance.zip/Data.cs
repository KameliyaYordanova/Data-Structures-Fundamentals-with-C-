﻿namespace _02.Data
{
    using _02.Data.Interfaces;
    using _02.Data.Models;
    using System;
    using System.Collections.Generic;
    using Wintellect.PowerCollections;

    public class Data : IRepository
    {
        private OrderedBag<IEntity> entities;

        public Data()
        {
            entities = new OrderedBag<IEntity>();
        }

        public Data(Data copy)
        {
            entities = copy.entities;
        }

        public int Size => entities.Count;

        public void Add(IEntity entity)
        {
            entities.Add(entity);
            var parentNode = GetById((int)entity.ParentId);

            if (parentNode != null)
            {
                parentNode.Children.Add(entity);
            }
        }

        public IRepository Copy()
        {
            Data copy = (Data)MemberwiseClone();

            return new Data(copy);
        }

        public IEntity DequeueMostRecent()
        {
            EnsureNoeEmpty();
            return entities.RemoveFirst();
        }

        public List<IEntity> GetAll()
        {
            return new List<IEntity>(entities);
        }

        public List<IEntity> GetAllByType(string type)
        {
            if (type != typeof(Invoice).Name && type != typeof(StoreClient).Name 
                && type != typeof(User).Name)
            {
                throw new InvalidOperationException($"Invalid type: {type}");
            }

            var result = new List<IEntity>(Size);

            for (int i = 0; i < Size; i++)
            {
                var current = entities[i];

                if (current.GetType().Name == type)
                {
                    result.Add(current);
                }
            }

            return result;
        }

        public IEntity GetById(int id)
        {
            if (id < 0 || id >= Size)
            {
                return null;
            }

            return entities[Size - 1 - id];
        }

        public List<IEntity> GetByParentId(int parentId)
        {
            var parentNode = GetById(parentId);

            if (parentNode == null)
            {
                return new List<IEntity>();
            }

            return parentNode.Children;
        }

        public IEntity PeekMostRecent()
        {
            EnsureNoeEmpty();
            return entities.GetFirst();
        }

        private void EnsureNoeEmpty()
        {
            if (Size == 0)
            {
                throw new InvalidOperationException("Operation on empty Data");
            }
        }
    }
}
