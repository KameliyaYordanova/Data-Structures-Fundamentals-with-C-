﻿namespace Tree
{
    using System;
    using System.Collections.Generic;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> children;

        public Tree(T value)
        {
            Value = value;
            Parent = null;
            children = new List<Tree<T>>();
        }

        public Tree(T value, params Tree<T>[] children)
            : this(value)
        {
            foreach (Tree<T> child in children)
            {
                child.Parent = this;
                this.children.Add(child);
            }
        }

        public T Value { get; private set; }

        public Tree<T> Parent { get; private set; }

        public IReadOnlyCollection<Tree<T>> Children => this.children.AsReadOnly();

        public bool IsRootDeleted { get; private set; }

        public ICollection<T> OrderBfs()
        {
            List<T> result = new List<T>();
            Queue<Tree<T>> queue = new Queue<Tree<T>>();

            if (IsRootDeleted)
            {
                return result;
            }

            queue.Enqueue(this);
            while (queue.Count > 0)
            {
                Tree<T> current = queue.Dequeue();
                result.Add(current.Value);

                foreach (Tree<T> child in current.Children)
                {
                    queue.Enqueue(child);
                }
            }

            return result;
        }

        public ICollection<T> OrderDfs()
        {
            List<T> result = new List<T>();

            if (IsRootDeleted)
            {
                return result;
            }
            this.Dfs(this, result);

            return result;
        }

        public void AddChild(T parentKey, Tree<T> child)
        {
            var parentSubtree = FindBfs(parentKey);
            CheckEmptyNode(parentSubtree);

            parentSubtree.children.Add(child);
        }

        public void RemoveNode(T nodeKey)
        {
            var currentNode = FindBfs(nodeKey);
            CheckEmptyNode(currentNode);

            foreach (var child in currentNode.Children)
            {
                child.Parent = null;
            }

            currentNode.children.Clear();

            var parentNode = currentNode.Parent;

            if (parentNode is null)
            {
                IsRootDeleted = true;
            }
            else
            {
                parentNode.children.Remove(currentNode);
            }
            currentNode.Value = default(T);
        }

        public void Swap(T firstKey, T secondKey)
        {
            var firstNode = FindBfs(firstKey);
            var secondNode = FindBfs(secondKey);
            CheckEmptyNode(firstNode);
            CheckEmptyNode(secondNode);

            if (firstNode.Parent == null)
            {
                SwapRoot(secondNode);
                return;
            }

            if (secondNode.Parent == null)
            {
                SwapRoot(firstNode);
                return;
            }

            var firstParent = firstNode.Parent;
            var secondParent = secondNode.Parent;

            firstNode.Parent = secondParent;
            secondNode.Parent = firstParent;

            int indexOfFirst = firstParent.children.IndexOf(firstNode);
            int indexOfSecond = secondParent.children.IndexOf(secondNode);

            firstParent.children[indexOfFirst] = secondNode;
            secondParent.children[indexOfSecond] = firstNode;
        }

        private void SwapRoot(Tree<T> secondNode)
        {
            Value = secondNode.Value;
            children.Clear();

            foreach (var child in secondNode.Children)
            {
                children.Add(child);
            }
        }

        private void Dfs(Tree<T> subtree, List<T> result)
        {
            foreach (var child in subtree.Children)
            {
                this.Dfs(child, result);
            }

            result.Add(subtree.Value);
        }

        private Tree<T> FindBfs(T value)
        {
            var queue = new Queue<Tree<T>>();
            queue.Enqueue(this);

            while (queue.Count > 0)
            {
                var subtree = queue.Dequeue();

                if (subtree.Value.Equals(value))
                {
                    return subtree;
                }

                foreach (var child in subtree.Children)
                {
                    queue.Enqueue(child);
                }
            }

            return null;
        }

        private void CheckEmptyNode(Tree<T> parentSubtree)
        {
            if (parentSubtree is null)
            {
                throw new ArgumentNullException();
            }
        }
    }
}
