﻿namespace Tree
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public class Tree<T> : IAbstractTree<T>
    {
        private readonly List<Tree<T>> children;

        public Tree(T key, params Tree<T>[] children)
        {
            Key = key;
            this.children = new List<Tree<T>>();

            foreach (var child in children)
            {
                AddChild(child);
                child.Parent = this;
            }
        }

        public T Key { get; private set; }

        public Tree<T> Parent { get; private set; }


        public IReadOnlyCollection<Tree<T>> Children
            => this.children.AsReadOnly();

        public void AddChild(Tree<T> child)
        {
            children.Add(child);
        }

        public void AddParent(Tree<T> parent)
        {
            Parent = parent;
        }

        public string GetAsString()
        {
            StringBuilder result = new StringBuilder();
            OrderDfsForString(0, result, this);

            return result.ToString().Trim();
        }

        public Tree<T> GetDeepestLeftomostNode()
        {
            var leafNodes = OrderBfs()
                .Where(node => this.IsLeaf(node));

            int depestNodeDepth = 0;
            Tree<T> depestNode = null;

            foreach (var node in leafNodes)
            {
                int currentDepth = GetDepthFromLeafToParent(node);

                if (currentDepth > depestNodeDepth)
                {
                    depestNodeDepth = currentDepth;
                    depestNode = node;
                }
            }

            return depestNode;
        }


        public List<T> GetLeafKeys()
        {
            var leafKeys = new List<T>();
            var nodes = new Queue<Tree<T>>();

            nodes.Enqueue(this);
            while (nodes.Count > 0)
            {
                var currentNode = nodes.Dequeue();

                if (IsLeaf(currentNode))
                {
                    leafKeys.Add(currentNode.Key);
                }

                foreach (var child in currentNode.Children)
                {
                    nodes.Enqueue(child);
                }
            }

            return leafKeys;
        }

        public List<T> GetMiddleKeys()
        {
            var middleKeys = new List<T>();
            var nodes = new Queue<Tree<T>>();

            nodes.Enqueue(this);
            while (nodes.Count > 0)
            {
                var currentNode = nodes.Dequeue();

                if (IsMiddle(currentNode))
                {
                    middleKeys.Add(currentNode.Key);
                }

                foreach (var child in currentNode.Children)
                {
                    nodes.Enqueue(child);
                }
            }

            return middleKeys;
        }

        public List<T> GetLongestPath()
        {
            var deepNodes = GetDeepestLeftomostNode();
            var resultedPath = new List<T>();
            var currentNode = deepNodes;

            while (currentNode != null)
            {
                resultedPath.Add(currentNode.Key);
                currentNode = currentNode.Parent;
            }

            resultedPath.Reverse();

            return resultedPath;
        }

        public List<List<T>> PathsWithGivenSum(int sum)
        {
            var result = new List<List<T>>();
            var currentPath = new List<T>();
            currentPath.Add(this.Key);

            var currentSum = Convert.ToInt32(this.Key);

            GetPathsWithSumDfs(this, result, currentPath, ref currentSum, sum);

            return result;
        }

        public List<Tree<T>> SubTreesWithGivenSum(int sum)
        {
            throw new NotImplementedException();
        }

        private void OrderDfsForString(int depth, StringBuilder result, Tree<T> subtree)
        {
            result.Append(new string(' ', depth))
                .Append(subtree.Key)
                .Append("\r\n"); // Environment.NewLine

            foreach (var child in subtree.Children)
            {
                OrderDfsForString(depth + 2, result, child);
            }
        }

        private bool IsLeaf(Tree<T> node)
        {
            return node.Children.Count == 0;
        }

        private bool IsRoot(Tree<T> node)
        {
            return node.Parent == null;
        }

        private bool IsMiddle(Tree<T> node)
        {
            return node.Parent != null && node.Children.Count > 0;
        }

        private List<Tree<T>> OrderBfs()
        {
            var result = new List<Tree<T>>();
            var nodes = new Queue<Tree<T>>();

            nodes.Enqueue(this);
            while (nodes.Count > 0)
            {
                var currentNode = nodes.Dequeue();
                result.Add(currentNode);

                foreach (var child in currentNode.Children)
                {
                    nodes.Enqueue(child);
                }
            }

            return result;
        }


        private int GetDepthFromLeafToParent(Tree<T> node)
        {
            int depth = 0;
            Tree<T> current = node;
            while (current.Parent != null)
            {
                depth++;
                current = current.Parent;
            }
            return depth;
        }

        private void GetPathsWithSumDfs(
            Tree<T> current, 
            List<List<T>> wanthedPaths, 
            List<T> currentPath, 
            ref int currentSum, 
            int wanthedSum)
        {
            foreach (var child in current.Children)
            {
                currentPath.Add(child.Key);
                currentSum += Convert.ToInt32(child.Key);

                GetPathsWithSumDfs(child, wanthedPaths, currentPath, ref currentSum, wanthedSum);
            }

            if (currentSum == wanthedSum)
            {
                wanthedPaths.Add(new List<T>(currentPath));
            }

            currentSum -= Convert.ToInt32(current.Key);
            currentPath.RemoveAt(currentPath.Count - 1);
        }
    }
}
