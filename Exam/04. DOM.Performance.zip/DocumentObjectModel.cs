﻿namespace _02.DOM
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using _02.DOM.Interfaces;
    using _02.DOM.Models;

    public class DocumentObjectModel : IDocument
    {
        public DocumentObjectModel(IHtmlElement root)
        {
            this.Root = root;
        }

        public DocumentObjectModel()
        {
            this.Root = new HtmlElement(ElementType.Document,
                new HtmlElement(ElementType.Html,
                    new HtmlElement(ElementType.Head),
                    new HtmlElement(ElementType.Body)
                )
            );
        }

        public IHtmlElement Root { get; private set; }

        IHtmlElement GetElementByType(IHtmlElement rootNode, ElementType type)
        {
            if (rootNode.Type == type)
                return rootNode;

            foreach (var child in rootNode.Children)
            {
                var n = GetElementByType(child, type);
                if (n != null)
                    return n;
            }

            return null;
        }

        void GetElementsByType(IHtmlElement rootNode, ElementType type, ref List<IHtmlElement> output)
        {
            foreach (var child in rootNode.Children)
            {
                GetElementsByType(child, type, ref output);
            }

            if (rootNode.Type == type)
                output.Add(rootNode);
        }

        public IHtmlElement GetElementByType(ElementType type)
        {
            return GetElementByType(this.Root, type);
        }

        public List<IHtmlElement> GetElementsByType(ElementType type)
        {
            List<IHtmlElement> output = new List<IHtmlElement>();
            GetElementsByType(this.Root, type, ref output);
            return output;
        }

        IHtmlElement GetElement(IHtmlElement rootNode, IHtmlElement htmlElement)
        {
            if (rootNode == htmlElement)
                return rootNode;

            foreach (var child in rootNode.Children)
            {
                IHtmlElement elem = GetElement(child, htmlElement);

                if (elem != null)
                    return elem;
            }

            return null;
        }

        public bool Contains(IHtmlElement htmlElement)
        {
            IHtmlElement elem = GetElement(this.Root, htmlElement);

            return elem != null;
        }

        public void InsertFirst(IHtmlElement parent, IHtmlElement child)
        {
            IHtmlElement refParent = GetElement(this.Root, parent);

            ValidateHtmlElement(refParent);
            child.Parent = refParent;
            refParent.Children.Insert(0, child);
        }

        private void ValidateHtmlElement(IHtmlElement htmlElement)
        {
            if (htmlElement == null)
                throw new InvalidOperationException();
        }

        public void InsertLast(IHtmlElement parent, IHtmlElement child)
        {
            IHtmlElement refParent = GetElement(this.Root, parent);

            ValidateHtmlElement(refParent);
            child.Parent = refParent;
            refParent.Children.Add(child);
        }

        public void Remove(IHtmlElement htmlElement)
        {
            IHtmlElement refElement = GetElement(this.Root, htmlElement);

            ValidateHtmlElement(refElement);

            refElement.Children.Clear();
            refElement.Parent.Children.Remove(refElement);
        }

        public void RemoveAll(ElementType elementType)
        {
            List<IHtmlElement> elements = GetElementsByType(elementType);
            foreach (var elem in elements)
            {
                elem.Children.Clear();
                elem.Parent.Children.Remove(elem);
            }
        }

        public bool AddAttribute(string attrKey, string attrValue, IHtmlElement htmlElement)
        {
            IHtmlElement refElement = GetElement(this.Root, htmlElement);

            ValidateHtmlElement(refElement);

            if (refElement.Attributes.ContainsKey(attrKey))
                return false;
            else
            {
                refElement.Attributes.Add(attrKey, attrValue);
                return true;
            }
        }

        public bool RemoveAttribute(string attrKey, IHtmlElement htmlElement)
        {
            IHtmlElement refElement = GetElement(this.Root, htmlElement);

            ValidateHtmlElement(refElement);

            if (refElement.Attributes.ContainsKey(attrKey))
            {
                refElement.Attributes.Remove(attrKey);
                return true;
            }
            else
            {
                return false;
            }
        }

        IHtmlElement GetElementById(IHtmlElement rootNode, string idValue)
        {
            if (rootNode.Attributes.ContainsValue(idValue))
                return rootNode;

            foreach (var child in rootNode.Children)
            {
                var n = GetElementById(child, idValue);
                if (n != null)
                    return n;
            }

            return null;
        }

        public IHtmlElement GetElementById(string idValue)
        {
            return GetElementById(this.Root, idValue);
        }

        private string GetSpaceIndent(int level)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < level * 2; i++)
            {
                sb.Append(" ");
            }
            return sb.ToString();
        }

        private void GetDomString(IHtmlElement rootNode, int startLevel, ref StringBuilder sb)
        {
            sb.Append($"{GetSpaceIndent(startLevel)}{rootNode.Type}\r\n");

            foreach (var child in rootNode.Children)
            {
                GetDomString(child, startLevel + 1, ref sb);
            }
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            GetDomString(this.Root, 0, ref sb);
            string output = sb.ToString();
            return output;
        }
    }
}
