﻿namespace _01._BrowserHistory
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using _01._BrowserHistory.Interfaces;

    public class BrowserHistory : IHistory
    {
        private List<ILink> histories;

        public BrowserHistory()
        {
            histories = new List<ILink>();
        }

        public int Size => histories.Count;

        public void Clear()
        {
            histories.Clear();
        }

        public bool Contains(ILink link)
        {
            return histories.Contains(link);
        }

        public ILink DeleteFirst()
        {
            ValidateHistory();
            var historie = histories[histories.Count - 1];
            histories.Remove(historie);

            return historie;
           
        }

        public ILink DeleteLast()
        {
            ValidateHistory();
            var index = histories[0];
            histories.Remove(index);

            return index;
        }

        public ILink GetByUrl(string url)
        {
            for (int i = 0; i < Size; i++)
            {
                var currentHistories = histories[i];

                if (currentHistories.Url == url)
                {
                    return currentHistories;
                }
            }

            return null;
        }

        public ILink LastVisited()
        {
            ValidateHistory();
            return histories[0];
        }

        public void Open(ILink link)
        {
            histories.Insert(0, link);
        }

        public int RemoveLinks(string url)
        {
            ValidateHistory();
            int removeHistoried = histories.RemoveAll(e => e.Url.IndexOf(url, StringComparison.OrdinalIgnoreCase) >= 0);

            return removeHistoried;
        }

        public ILink[] ToArray()
        {
            return histories.ToArray();
        }

        public List<ILink> ToList()
        {
            return histories;
        }

        public string ViewHistory()
        {
            if (histories.Count == 0)
                return "Browser history is empty!";
            else
            {
                StringBuilder sb = new StringBuilder();
                foreach (var item in histories)
                {
                    sb.Append($"-- {item.Url} {item.LoadingTime}s\r\n");
                }
                return sb.ToString();
            }
        }

        private void ValidateHistory()
        {
            if (Size == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}
