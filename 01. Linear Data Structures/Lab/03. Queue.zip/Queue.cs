﻿namespace Problem03.Queue
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Queue<T> : IAbstractQueue<T>
    {
        private Node<T> head;

        public Queue()
        {
            head = null;
            Count = 0;
        }

        public int Count { get; private set; }

        public bool Contains(T item)
        {
            Node<T> current = head;

            while (current != null)
            {
                if (current.Value.Equals(item))
                {
                    return true;
                }

                current = current.Next;
            }

            return false;
        }

        public T Dequeue()
        {
            ValidateIfEmpty();
            Node<T> current = head;
            head = head.Next;

            Count--;
            return current.Value;
        }

        public void Enqueue(T item)
        {
            Node<T> current = head;
            Node<T> toInsert = new Node<T>(item);

            if (current == null)
            {
                head = toInsert;
            }
            else
            {
                while (current.Next != null)
                {
                    current = current.Next;
                }

                current.Next = toInsert;
            }

            Count++;
        }

        public T Peek()
        {
            ValidateIfEmpty();
            return head.Value;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> current = head;

            while (current != null)
            {
                yield return current.Value;
                current = current.Next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
            => GetEnumerator();

        private void ValidateIfEmpty()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}