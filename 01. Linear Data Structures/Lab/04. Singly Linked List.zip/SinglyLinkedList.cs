﻿namespace Problem04.SinglyLinkedList
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class SinglyLinkedList<T> : IAbstractLinkedList<T>
    {
        private Node<T> head;

        public int Count { get; private set; }

        public SinglyLinkedList()
        {
            head = null;
            Count = 0;
        }

        public void AddFirst(T item)
        {
            Node<T> toInsert = new Node<T>(item, head);
            head = toInsert;
            Count++;
        }

        public void AddLast(T item)
        {
            Node<T> toInsert = new Node<T>(item);
            Node<T> current = head;

            if (current == null)
            {
                head = toInsert;
            }
            else
            {
                while (current.Next != null)
                {
                    current = current.Next;
                }
                current.Next = toInsert;
            }

            Count++;
        }

        public T GetFirst()
        {
            ValidateIsEmpty();
            return head.Value;
        }

        public T GetLast()
        {
            ValidateIsEmpty();

            Node<T> current = head;

            while (current.Next != null)
            {
                current = current.Next;
            }

            return current.Value;
        }

        public T RemoveFirst()
        {
            ValidateIsEmpty();
            Node<T> firstNode = head;
            head = head.Next;

            Count--;

            return firstNode.Value;
        }

        public T RemoveLast()
        {
            ValidateIsEmpty();
            Node<T> current = head;
            Node<T> last = null;

            if (current.Next == null)
            {
                last = head;
                head = null;
            }
            else
            {
                while (current != null)
                {
                    if (current.Next.Next == null)
                    {
                        last = current.Next;
                        current.Next = null;
                        break;
                    }
                    current = current.Next;
                }
            }

            Count--;
            return last.Value;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> current = head;
            while (current != null)
            {
                yield return current.Value;
                current = current.Next;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
            => this.GetEnumerator();

        private void ValidateIsEmpty()
        {
            if (Count == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}