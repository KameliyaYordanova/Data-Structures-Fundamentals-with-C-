﻿namespace _04.BinarySearchTree
{
    using System;

    public class BinarySearchTree<T> : IAbstractBinarySearchTree<T>
        where T : IComparable<T>
    {
        public BinarySearchTree()
        {
        }

        public BinarySearchTree(Node<T> root)
        {
            Copy(root);
            // TODO: Create copy from root
        }

        private void Copy(Node<T> root)
        {
            if (root != null)
            {
                Insert(root.Value);
                Copy(root.LeftChild);
                Copy(root.RightChild);
            }
        }

        public Node<T> Root { get; private set; }

        public Node<T> LeftChild { get; private set; }

        public Node<T> RightChild { get; private set; }

        public T Value => this.Root.Value;

        public bool Contains(T element)
        {
            var current = Root;

            while (current != null)
            {
                if (IsLess(element, current.Value))
                {
                    current = current.LeftChild;
                }
                else if(IsGreate(element, current.Value))
                {
                    current = current.RightChild;
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        public void Insert(T element)
        {
            var toInsert = new Node<T>(element, null, null);

            if (Root == null)
            {
                Root = toInsert;
            }
            else
            {
                var current = Root;
                Node<T> prev = null;

                while (current != null)
                {
                    prev = current;
                    if (IsLess(element, current.Value))
                    {
                        current = current.LeftChild;
                    }
                    else if(IsGreate(element, current.Value))
                    {
                        current = current.RightChild;
                    }
                    else
                    {
                        return;
                    }
                }

                if (IsLess(element, prev.Value))
                {
                    prev.LeftChild = toInsert;
                    if (LeftChild == null)
                    {
                        LeftChild = toInsert;
                    }
                }
                else
                {
                    prev.RightChild = toInsert;
                    if (RightChild == null)
                    {
                        RightChild = toInsert;
                    }
                }
            }
        }

        public IAbstractBinarySearchTree<T> Search(T element)
        {
            var current = this.Root;

            while (current != null && !this.AreEqual(element, current.Value))
            {
                if (IsLess(element, current.Value))
                {
                    current = current.LeftChild;
                }
                else if (IsGreate(element, current.Value))
                {
                    current = current.RightChild;
                }
            }

            return new BinarySearchTree<T>(current);
        }


        private bool IsLess(T element, T value)
        {
            return element.CompareTo(value) < 0;
        }


        private bool IsGreate(T element, T value)
        {
            return element.CompareTo(value) > 0;
        }


        private bool AreEqual(T element, T value)
        {
            return element.CompareTo(value) == 0;
        }
    }
}
