﻿namespace _03.PriorityQueue
{
    using System;
    using System.Collections.Generic;

    public class PriorityQueue<T> : IAbstractHeap<T>
        where T : IComparable<T>
    {
        private List<T> elements;

        public PriorityQueue()
        {
            elements = new List<T>();
        }

        public int Size { get { return elements.Count; } }

        public T Dequeue()
        {
            var firstElement = Peek();
            Swap(0, Size - 1);
            elements.RemoveAt(Size - 1);
            HeapIfDown();

            return firstElement;
        }

        private void HeapIfDown()
        {
            int index = 0;
            int leftChildIndex = GetLeftChildIndex(index);

            while (IndexIsValid(leftChildIndex) && IsLess(index, leftChildIndex))
            {
                int toSwapWith = leftChildIndex;
                int rightChildIndex = GetRightChildIndex(index);

                if (IndexIsValid(rightChildIndex) && IsLess(toSwapWith, rightChildIndex))
                {
                    toSwapWith = rightChildIndex;
                }

                Swap(toSwapWith, index);
                index = toSwapWith;
                leftChildIndex = GetLeftChildIndex(index);
            }
        }

        public void Add(T element)
        {
            elements.Add(element);
            HeapIfUp();
        }

        public T Peek()
        {
            EnsureNotEmpty();
            return elements[0];
        }

        private void HeapIfUp()
        {
            int currentIndex = Size - 1;
            int parentIndex = GetParentIndex(currentIndex);

            while (IndexIsValid(currentIndex) && IsGreater(currentIndex, parentIndex))
            {
                Swap(currentIndex, parentIndex);

                currentIndex = parentIndex;
                parentIndex = GetParentIndex(currentIndex);
            }
        }

        private void Swap(int currentIndex, int parentIndex)
        {
            var temp = elements[currentIndex];
            elements[currentIndex] = elements[parentIndex];
            elements[parentIndex] = temp;
        }

        private bool IsLess(int childIndex, int parentIndex)
        {
            return elements[childIndex].CompareTo(elements[parentIndex]) < 0;
        }

        private bool IsGreater(int childIndex, int parentIndex)
        {
            return elements[childIndex].CompareTo(elements[parentIndex]) > 0;
        }

        private int GetParentIndex(int childIndex)
        {
            return (childIndex - 1) / 2;
        }

        private bool IndexIsValid(int index)
        {
            return index < Size;
        }

        private void EnsureNotEmpty()
        {
            if (Size == 0)
            {
                throw new InvalidOperationException();
            }
        }

        private int GetLeftChildIndex(int parentIndex)
        {
            return 2 * parentIndex + 1;
        }

        private int GetRightChildIndex(int parentIndex)
        {
            return 2 * parentIndex + 2;
        }
    }
}
