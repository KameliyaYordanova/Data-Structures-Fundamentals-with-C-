﻿namespace _02.MaxHeap
{
    using System;
    using System.Collections.Generic;

    public class MaxHeap<T> : IAbstractHeap<T>
        where T : IComparable<T>
    {
        private List<T> elements;

        public MaxHeap()
        {
            elements = new List<T>();
        }

        public int Size { get { return elements.Count; } }

        public void Add(T element)
        {
            elements.Add(element);
            HeapIfUp();
        }

        private void HeapIfUp()
        {
            int currentIndex = Size - 1;
            int parentIndex = GetParentIndex(currentIndex);

            while (IndexIsValid(currentIndex) && IsGreater(currentIndex, parentIndex))
            {
                var temp = elements[currentIndex];
                elements[currentIndex] = elements[parentIndex];
                elements[parentIndex] = temp;

                currentIndex = parentIndex;
                parentIndex = GetParentIndex(currentIndex);
            }
        }

        private bool IsGreater(int childIndex, int parentIndex)
        {
            return elements[childIndex].CompareTo(elements[parentIndex]) > 0;
        }

        private int GetParentIndex(int childIndex)
        {
            return (childIndex - 1) / 2;
        }

        private bool IndexIsValid(int index)
        {
            return index > 0;
        }

        public T Peek()
        {
            EnsureNotEmpty();
            return elements[0];
        }

        private void EnsureNotEmpty()
        {
            if (Size == 0)
            {
                throw new InvalidOperationException();
            }
        }
    }
}
