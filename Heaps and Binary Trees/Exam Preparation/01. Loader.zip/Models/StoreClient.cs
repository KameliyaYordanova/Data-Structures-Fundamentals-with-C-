﻿namespace _01.Loader.Models
{
    public class StoreClient : BaseEntity
    {
        public StoreClient(int id, int? parentId) 
            : base(id, parentId)
        {
        }
    }
}
