﻿namespace _01.Loader
{
    using _01.Loader.Interfaces;
    using _01.Loader.Models;
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class Loader : IBuffer
    {
        private List<IEntity> elements;

        public Loader()
        {
            elements = new List<IEntity>();
        }

        public int EntitiesCount => elements.Count;

        public void Add(IEntity entity)
        {
            elements.Add(entity);
        }

        public void Clear()
        {
            elements.Clear();
        }

        // you looked letter!!! 
        public bool Contains(IEntity entity)
        {
            return elements.Contains(entity);
        }

        public IEntity Extract(int id)
        {
           IEntity found = GetById(id);

            if (found != null)
            {
                elements.Remove(found);
            }

            return found;
        }

       
        public IEntity Find(IEntity entity)
        {
            return GetById(entity.Id);
        }

        public List<IEntity> GetAll()
        {
            return new List<IEntity>(elements);
        }

        public IEnumerator<IEntity> GetEnumerator()
        {
           return elements.GetEnumerator();
        }

        public void RemoveSold()
        {
            elements.RemoveAll(e => e.Status == BaseEntityStatus.Sold);
        }

        public void Replace(IEntity oldEntity, IEntity newEntity)
        {
            int indexOfEntity = elements.IndexOf(oldEntity);
            ValidateEntity(indexOfEntity);
            elements[indexOfEntity] = newEntity;
        }

        public List<IEntity> RetainAllFromTo(BaseEntityStatus lowerBound, BaseEntityStatus upperBound)
        {
            var result = new List<IEntity>(EntitiesCount);
            int lowerBoundIndex = (int)lowerBound;
            int upperBoundIndex = (int)upperBound;

            for (int i = 0; i < EntitiesCount; i++)
            {
                var entity = elements[i];
                int entityStatusIndex = (int)entity.Status;

                if (entityStatusIndex >= lowerBoundIndex 
                    && entityStatusIndex <= upperBoundIndex)
                {
                    result.Add(entity);
                }
            }

            return result;
        }

        public void Swap(IEntity first, IEntity second)
        {
            int indexOfFirst = elements.IndexOf(first);
            int indexOfSecond = elements.IndexOf(second);
            ValidateEntity(indexOfFirst);
            ValidateEntity(indexOfSecond);

            // manner of Swap!!!
            var temp = elements[indexOfFirst];
            elements[indexOfFirst] = elements[indexOfSecond];
            elements[indexOfSecond] = temp;
        }

        public IEntity[] ToArray()
        {
            return elements.ToArray();
        }

        public void UpdateAll(BaseEntityStatus oldStatus, BaseEntityStatus newStatus)
        {
            for (int i = 0; i < EntitiesCount; i++)
            {
                var current = elements[i];

                if (current.Status == oldStatus)
                {
                    current.Status = newStatus;
                }
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        private IEntity GetById(int id)
        {
            for (int i = 0; i < EntitiesCount; i++)
            {
                var currentEntitis = elements[i];

                if (currentEntitis.Id == id)
                {
                    return currentEntitis;
                }
            }

            return null;
        }


        private void ValidateEntity(int index)
        {
            if (index == -1)
            {
                throw new InvalidOperationException("Entity not found");
            }
        }
    }
}
