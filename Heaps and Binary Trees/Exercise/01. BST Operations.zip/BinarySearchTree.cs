﻿namespace _01.BSTOperations
{
    using System;
    using System.Collections.Generic;

    public class BinarySearchTree<T> : IAbstractBinarySearchTree<T>
        where T : IComparable<T>
    {
        public BinarySearchTree()
        {
        }

        public BinarySearchTree(Node<T> root)
        {
            Copy(root);
            // TODO: Create copy from root
        }


        public Node<T> Root { get; private set; }

        public Node<T> LeftChild { get; private set; }

        public Node<T> RightChild { get; private set; }

        public T Value => this.Root.Value;

        public int Count => Root.Count;

        public bool Contains(T element)
        {
            Node<T> current = Root;

            while (current != null)
            {
                if (IsLess(element, current.Value))
                {
                    current = current.LeftChild;
                }
                else if(IsGreater(element, current.Value))
                {
                    current = current.RightChild;
                }
                else
                {
                    return true;
                }
            }

            return false;
        }

        public void Insert(T element)
        {
            Node<T> toInsert = new Node<T>(element, null, null);

            if (Root == null)
            {
                Root = toInsert;
            }
            else
            {
                InsertElementDfs(Root, null, toInsert);
            }
        }

        private void InsertElementDfs(Node<T> current, Node<T> previous, Node<T> toInsert)
        {
            if (current == null && IsLess(toInsert.Value, previous.Value))
            {
                previous.LeftChild = toInsert;
               
                if (LeftChild == null)
                {
                    LeftChild = toInsert;
                }
                return;
            }

            if (current == null && IsGreater(toInsert.Value, previous.Value))
            {
                previous.RightChild = toInsert;
                
                if (RightChild == null)
                {
                    RightChild = toInsert;
                }
                return;
            }

            if (IsLess(toInsert.Value, current.Value))
            {
                InsertElementDfs(current.LeftChild, current, toInsert);
                current.Count++;
            }
            else if(IsGreater(toInsert.Value, current.Value))
            {
                InsertElementDfs(current.RightChild, current, toInsert);
                current.Count++;
            }
        }

        public IAbstractBinarySearchTree<T> Search(T element)
        {
            Node<T> current = Root;

            while (current != null)
            {
                if (IsLess(element, current.Value))
                {
                    current = current.LeftChild;
                }
                else if (IsGreater(element, current.Value))
                {
                    current = current.RightChild;
                }
                else
                {
                    break;
                }
            }

            return new BinarySearchTree<T>(current);
        }

        public void EachInOrder(Action<T> action)
        {
            EachInOrderDfs(Root, action);
        }

        public List<T> Range(T lower, T upper)
        {
            var result = new List<T>();
            var nodes = new Queue<Node<T>>();

            nodes.Enqueue(Root);

            while (nodes.Count > 0)
            {
                var current = nodes.Dequeue();

                if (IsLess(lower, current.Value) && IsGreater(upper, current.Value))
                {
                    result.Add(current.Value);
                }
                else if(AreEqual(lower, current.Value) || AreEqual(upper, current.Value))
                {
                    result.Add(current.Value);
                }

                if (current.LeftChild != null)
                {
                    nodes.Enqueue(current.LeftChild);
                }
                if (current.RightChild != null)
                {
                    nodes.Enqueue(current.RightChild);
                }

            }

            return result;
        }

        public void DeleteMin()
        {
            EnsureNotEmpty();
            Node<T> current = Root;
            Node<T> previous = null;

            if (Root.LeftChild == null)
            {
                Root = Root.RightChild;
            }
            else
            {
                while (current.LeftChild != null)
                {
                    current.Count--;
                    previous = current;
                    current = current.LeftChild;
                }

                previous.LeftChild = current.RightChild;
            }
           
        }

        public void DeleteMax()
        {
            EnsureNotEmpty();
            Node<T> current = Root;
            Node<T> previous = null;

            if (Root.RightChild == null)
            {
                Root = Root.LeftChild;
            }
            else
            {

                while (current.RightChild != null)
                {
                    current.Count--;
                    previous = current;
                    current = current.RightChild;
                }

                previous.RightChild = current.LeftChild;
            }

        }

        public int GetRank(T element)
        {
            return GetRankdDfs(Root, element);
        }

        private int GetRankdDfs(Node<T> current, T element)
        {
            if (current == null)
            {
                return 0;
            }

            if (IsLess(element, current.Value))
            {
               return GetRankdDfs(current.LeftChild, element);
            }
            else if(AreEqual(element, current.Value))
            {
                return GetNodeCount(current);
            }

            return GetNodeCount(current.LeftChild) 
                + 1 + GetRankdDfs(current.RightChild, element);
        }

        private int GetNodeCount(Node<T> current)
        {
            return current == null ? 0 : current.Count;
        }

        private void Copy(Node<T> current)
        {
            if (current != null)
            {
                Insert(current.Value);
                Copy(current.LeftChild);
                Copy(current.RightChild);
            }
        }

        private void EachInOrderDfs(Node<T> currrent, Action<T> action)
        {
            if (currrent != null)
            {
                EachInOrderDfs(currrent.LeftChild, action);
                action.Invoke(currrent.Value);
                EachInOrderDfs(currrent.RightChild, action);
            }
        }

        private bool IsLess(T firstElement, T secondElemnt)
        {
            return firstElement.CompareTo(secondElemnt) < 0;
        }

        private bool IsGreater(T firstElement, T secondElemnt)
        {
            return firstElement.CompareTo(secondElemnt) > 0;
        }

        private bool AreEqual(T firstElement, T secondElemnt)
        {
            return firstElement.CompareTo(secondElemnt) == 0;
        }

        private void EnsureNotEmpty()
        {
            if (Root == null)
            {
                throw new InvalidOperationException();
            }
        }
    }
}
